#include "class.h"
int main()
{
    clas pc;
    pc.SorteazaVector("descrescator");
    pc.AfisazaVector();
}
